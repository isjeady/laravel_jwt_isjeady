<template>
    <h1>Laravel 5 Vue SPA Authentication</h1>
</template>
