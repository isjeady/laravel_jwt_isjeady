<template>
    <h1>Laravel 5 – Our Cool Dashboard</h1>
</template>