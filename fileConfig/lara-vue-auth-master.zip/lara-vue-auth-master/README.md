# lara-vue-auth
A repo for laravel vue authentication tutorial.

# How to run 
1. Clone the repo
2. Run 
 	`composer install`
3. Run 
	`npm install`

4. Set your database credentials in .env
5. Run 
	`php artisan serve`
